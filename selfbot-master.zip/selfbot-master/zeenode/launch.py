import os
from zeenode.load import load

window = 'mode 90,19'
os.system(window)
load()